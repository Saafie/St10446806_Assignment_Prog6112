import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

class CoinTossGame{
    private static Random random = new Random(); // Initialize Random object

    public static boolean coinTossGame() {
        return random.nextBoolean();
    }}
class player1{
    public player1 (String p1){
        Scanner player = new Scanner(System.in);

    }}


class playerToss extends CoinTossGame{
    //Declares arraylist
    private ArrayList<String> names = new ArrayList<String>();
    private ArrayList<String> choice= new ArrayList<String>();
    private ArrayList<Integer> heads = new ArrayList<Integer>();
    private ArrayList<Integer> tails = new ArrayList<>();
    private String[][] rchoice;

    public playerToss(String rChoices, String right) {
        Scanner player = new Scanner(System.in);
        String p;

        for (int i = 0; i < 2; i++) { // allows player to enter names
            System.out.print("Enter Player" + (i + 1) + " Name: ");
            p = player.next();
            names.add(p);
        }

        System.out.print("How many rounds?: ");
        int number = Integer.parseInt(player.next()); //allows players to enter rounds



        System.out.println("Heads/Tails: "); //allows players to enter heads or tails each round
        rchoice = new String[2][number];
        for (int b = 0; b< number; b++) {
            System.out.println(" Round " + (b + 1));
            for (int j = 0; j < names.size(); j++) {
                System.out.print(names.get(j)  + ": ");
                String choices = player.next();
                rchoice[j][b] = choices;
                player.nextLine();
            }}

        for (int i = 0; i < number; i++) {
            boolean result = CoinTossGame.coinTossGame();
            right = result ? "Heads" : "Tails";
            if (result) {
                heads.add(1); //adds a point to heads
            } else {
                tails.add(1);//adds point to tails
            }
            System.out.println("Round " + (i+1) +"\n"+"-----------------");
            System.out.println("Heads count: " + heads.size());
            System.out.println("Tails count: " + tails.size());
            System.out.println(right);
            System.out.println("-----------------"+"\n");} //Prints out the count of tails and heads
        Winner();
    }


    public void Winner(){

        if(tails.size() < heads.size()){ // annonunces winner
            System.out.println("Winner"+"\n"+"-----------------");
            System.out.println("Congratulations " + names.getFirst() + " you won CoinToss ");}
        else if(tails.size() > heads.size()){
            System.out.println("Winner"+"\n"+"-----------------");
            System.out.println("Congratulations " + names.getLast() + " you won CoinToss ");}
        else{
            System.out.println("Its a tie");}
    }

}

public class Main {
    public static void main(String[] args) {
        String rChoices ="";
        String result = "";
        new playerToss(rChoices, result); // Start the game
    }
}
