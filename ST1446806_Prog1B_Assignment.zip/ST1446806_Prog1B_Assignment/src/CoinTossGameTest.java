import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PlayerTossTest {


    @BeforeEach
    void setUp() {
        ArrayList<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");

        // choices for 3 rounds
        String[][] roundChoices = {
                {"Heads", "Tails", "Heads"}, // Choices for Alice
                {"Tails", "Heads", "Tails"}  // Choices for Bob
        };


    }

    @Test
    void booleanTest(){ //tests the boolean against what was entered
        String result = "";
        String rChoice ="";
        String bool = String.valueOf(new playerToss(rChoice,result));
        CoinTossGame.coinTossGame();
        assertEquals("heads","tails");

    }

    @Test
    void testPlayRounds() { //tests the choices
        Scanner scanner = new Scanner(System.in);
        String rChoice = "heads";
        String right ="tails";
        assertEquals("Heads", rChoice );
        assertEquals("Tails", rChoice);
        assertEquals("Heads", right );
        assertEquals("Tails", right);


    }

    @Test
    void testDetermineWinner() { //tests the winner
        String right ="Alice";
        String rChoices = "John";
        String winner = String.valueOf(new playerToss(rChoices,right));
        assertEquals("Alice wins!", right);
        assertEquals("Alice wins!", rChoices);
    }
}