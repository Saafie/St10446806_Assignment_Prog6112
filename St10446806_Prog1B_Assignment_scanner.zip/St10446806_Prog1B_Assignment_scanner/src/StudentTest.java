
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StudentTest {


    private int iD;
    private int age;
    private void assertTrue(int testiD, ArrayList<Integer> iDs) {
    }

    @Test
    void saveStudent() {
        Student.saveStudent(iD,age);
    }

    @Test
    void testSearchStudent() {// tests the id if it matches to find student
        Student.searchStudent();
        int testiD;
        testiD= iD;
        assertTrue(testiD, Student.iDs);
        System.out.println("STUDENT FOUND");
    }



    @Test
    void testSearchStudent_StudentNotFound() {// tests the id if it doesn't match to find student
        Student.searchStudent();
        int testiD;
        testiD= iD;
        assertEquals(testiD, Student.iDs);
        System.out.println("STUDENT NOT FOUND");
    }


    @Test
    void testDeleteStudent() {// tests the id if it matches to find student and deletes details
        Student.deleteStudent();
        int testiD;
        testiD= iD;
        assertEquals(testiD, Student.iDs);
        System.out.println("STUDENT SUCCESSFULLY DELETED");
    }

    @Test
    void testDeleteStudent_StudentNotFound() {// tests the id if it doesn't match student id
        Student.deleteStudent();
        int testiD;
        testiD= iD;
        assertEquals(testiD, Student.iDs);
        System.out.println("STUDENT NOT FOUND");
    }

    @Test
    void testStudentAge_StudentValidAge(){// checks age is above 16

        int i = age;
        boolean age = i>16;
        assertEquals(age, Student.ages);

    }

    @Test
    void testStudentAge_StudentAgeInvalid(){//checks age is below 16
        int i = age;
        boolean age = i<16;
        assertEquals(age, Student.ages);
    }

    @Test
    void testStudentAge_StudentAgeInvalidCharacter(){//checks age don't have special characters

        String i = "@!#$%^&*";
        assertEquals(i, Student.ages);
    }
}