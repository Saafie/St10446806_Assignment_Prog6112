import java.util.ArrayList;
import java.util.Scanner;

public class Student{
    //Declaring
    static ArrayList<Integer> iDs = new ArrayList<Integer>();
    static ArrayList<String> studentNames = new ArrayList<String>();
    static ArrayList<Integer> ages = new ArrayList<Integer>();
    static ArrayList<String> emails = new ArrayList<String>();
    static ArrayList<String> course = new ArrayList<String>();
    int i = 0;

    public static void main(String[] args) {
        Application();//Allows the whole application to work
    }

    public static void Application() { //Starter to the application
        Scanner Option = new Scanner(System.in);
        //Initializing
        int i = 0;
        System.out.println("STUDENT APPLICATION");
        exitStudentApplication();

    }


    public static void Options(String Options) {
        Scanner numbers = new Scanner(System.in);
        int i = 0;
        int iD = 0;
        int age = 0;
        String number;
        System.out.println(Options);
        while (true) {

            number = numbers.nextLine();
            if (number.contains("1") || number.contains("(1)")) { //allows you to save a student
                saveStudent(iD, age);
            } else if (number.contains("2") || number.contains("(2)")) { //allows you to search for a student
                searchStudent();
            } else if (number.contains("3") || number.contains("(3)")) { //allows you to delete a student
                deleteStudent();
            } else if (number.contains("4") || number.contains("(4)")) { //allows you to look at all the students
                printStudentReport();
            } else if (number.contains("5") || number.contains("(5)")) { //allows you to exit the student application
                System.out.println("Goodbye");


            }
        }
    }


    public static void saveStudent(int iD, int age) {
        Scanner details = new Scanner(System.in);
        String Options = "";
        System.out.print("Student ID: ");
        iD = details.nextInt();
        details.nextLine();
        iDs.add(iD); // adds the student ID to Array list

        System.out.print("Student Name: ");
        String studentName = details.nextLine();
        studentNames.add(studentName); // adds the student names to Array list

        while (true) { // Checks if they have a valid age
            System.out.print("Student age: ");
            age = details.nextInt();
            if (age >= 16) { //checks if age is above 16
                ages.add(age);
                break;
            } else { //if age is below 16
                System.out.println("You have entered a incorrect age!!!" + "\n" + "Please re-enter the student age>>");
                details.nextLine();
            }
        }


        System.out.print("Enter Email: ");
        String email = details.next();
        details.nextLine();
        emails.add(email); // adds email to the emails ArrayList


        System.out.print("Enter course: ");
        String courseType = details.nextLine();
        course.add(courseType);// adds courseType to the course ArrayList

        System.out.println("Student details have been successfully saved");
        exitStudentApplication();
        details.close();
    }


    public static void searchStudent() {
        String Options = "";
        Scanner studentSearch = new Scanner(System.in);

        while (true) {
            System.out.println("Enter Student ID: ");
            int search = studentSearch.nextInt();
            if (iDs.contains(search)) { // checks if the searched ID matches the ID number searched
                int found = 0;

                for (int i = 0; i < iDs.size(); i++) {
                    if (iDs.get(i).equals((search))) {
                        //Gets the index of the ID searched and Displays its details
                        String print = "Student ID:" + iDs.get(i) + "\n" +
                                "STUDENT NAME: " + studentNames.get(i) + "\n" +
                                "STUDENT AGE: " + ages.get(i) + "\n" +
                                "STUDENT EMAILS: " + emails.get(i) + "\n" +
                                "STUDENT COURSE: " + course.get(i);
                        System.out.println(print);
                        found++; // makes the found ID match the search ID

                    }
                }
                break;
            } else {
                System.out.println("Student ID not found re-enter ID number");
            }
        }
        exitStudentApplication();//Bring the option to exit or go back to main menu
        studentSearch.close();
    }


    public static void deleteStudent() {
        String Options = "";
        Scanner delete = new Scanner(System.in);
        System.out.println("Enter Student Number ID to delete: ");
        int iD = delete.nextInt();
        if (iDs.contains(iD)) {//checks if the ArrayList iDs contains the typed requested ID
            int foundIndex = -1;

            for (int i = 0; i < iDs.size(); i++) { //Searches through the array
                if (iDs.get(i).equals((iD))) { //Searches each index to see which index in the array has the ID needed to be deleted
                    System.out.println("Are you sure you want to delete student number " + iD + " from the system? Yes (y) to delete");
                    delete.nextLine();
                    String answer = delete.nextLine();
                    if (answer.contains("y") || answer.contains("yes")) { //Confirms if the Student needs to be deleted
                        foundIndex = i;
                    }

                    if (foundIndex != -1) {
                        // Removes all the Students details of the foundIndex
                        iDs.remove(foundIndex);
                        studentNames.remove(foundIndex);
                        ages.remove(foundIndex);
                        emails.remove(foundIndex);
                        course.remove(foundIndex);

                        System.out.println("Student with student ID: " + iD + " WAS deleted."); //Student is deleted
                    }
                }
            }
        } else {
            System.out.println("Student with student ID: " + iD + " was not found!"); //Student isn't found

        }
        exitStudentApplication();//Bring the option to exit or go back to main menu
    }


    public static void printStudentReport() {  //Prints the all students reports
        StringBuilder report = new StringBuilder();
        String Options = "";
        report.append("Full Student Reports:\n\n");
        for (int i = 0; i < studentNames.size(); i++) {
            report.append("STUDENT ").append(i + 1).append("\n");
            report.append("--------------------------").append("\n");
            report.append("STUDENT ID: ").append(iDs.get(i)).append("\n");
            report.append("STUDENT NAME: ").append(studentNames.get(i)).append("\n");
            report.append("STUDENT AGE: ").append(ages.get(i)).append("\n");
            report.append("STUDENT EMAIL: ").append(emails.get(i)).append("\n");
            report.append("STUDENT COURSE: ").append(course.get(i)).append("\n");
            report.append("--------------------------").append("\n");
        }

        System.out.println(report); //Displays the entire report of all students
        exitStudentApplication();//Bring the option to exit or go back to main menu
    }


    public static void exitStudentApplication() {//Method that gives the option to exit or go back to main menu
        String Options = """
                Please select one of the following menu items:
                (1) Capture a new Student
                (2) Search for a student
                (3) Delete a student
                (4) Print student Report\

                (5) Exit Application""";

        Scanner Option = new Scanner(System.in);
        String message = "Enter (1) to launch menu or any other key to exit";
        System.out.println("***************************************************************"
                + "\n" + message);
        String number = Option.nextLine();
        if (number.contains("1") || number.contains("(1)")) {
            Options(Options); //Leads to the method that allows you chose an option 1-5
        } else {
            System.out.println("Goodbye");
        }
    }
}

